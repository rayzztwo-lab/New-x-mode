package com.gameturbo.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import android.media.AudioManager
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pembacaan sistem yang dipakai bersama oleh lobby, panel, screenshot dan perekam. */
object Sys {

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().split(" ")[0].toLong()
    } catch (e: Exception) {
        null
    }

    /** Rata-rata clock CPU saat ini dibanding clock maksimum (persen). -1 kalau tidak terbaca. */
    fun cpuPct(): Int {
        var sum = 0.0
        var n = 0
        for (i in 0 until 16) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val c = readLong(b + "scaling_cur_freq") ?: continue
            val m = readLong(b + "cpuinfo_max_freq") ?: continue
            if (m > 0L) {
                sum += c.toDouble() / m.toDouble()
                n++
            }
        }
        return if (n == 0) -1 else (sum / n * 100.0).toInt().coerceIn(0, 100)
    }

    /** Beban/clock GPU (persen) kalau HP mengizinkan dibaca. -1 kalau tidak. */
    fun gpuPct(): Int {
        readLong("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")?.let { return it.toInt().coerceIn(0, 100) }
        readLong("/sys/kernel/gpu/gpu_busy")?.let { return it.toInt().coerceIn(0, 100) }
        val dirs = ArrayList<String>()
        dirs.add("/sys/class/kgsl/kgsl-3d0/devfreq/")
        try {
            File("/sys/class/devfreq").listFiles()?.forEach {
                val n = it.name.lowercase()
                if (n.contains("gpu") || n.contains("mali") || n.contains("kgsl")) dirs.add(it.path + "/")
            }
        } catch (_: Exception) {
        }
        for (d in dirs) {
            val c = readLong(d + "cur_freq") ?: continue
            val m = readLong(d + "max_freq") ?: continue
            if (m > 0L) return (c * 100L / m).toInt().coerceIn(0, 100)
        }
        return -1
    }

    /** Rata-rata clock CPU saat ini dalam GHz. -1 kalau tidak terbaca. */
    fun cpuGhz(): Double {
        var sum = 0.0
        var n = 0
        for (i in 0 until 16) {
            val c = readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq") ?: continue
            sum += c.toDouble()
            n++
        }
        return if (n == 0) -1.0 else sum / n / 1_000_000.0
    }

    /** Clock GPU saat ini dalam MHz. -1 kalau tidak terbaca. */
    fun gpuMhz(): Double {
        readLong("/sys/class/kgsl/kgsl-3d0/gpuclk")?.let { if (it > 0L) return it / 1_000_000.0 }
        val dirs = ArrayList<String>()
        dirs.add("/sys/class/kgsl/kgsl-3d0/devfreq/")
        try {
            File("/sys/class/devfreq").listFiles()?.forEach {
                val n = it.name.lowercase()
                if (n.contains("gpu") || n.contains("mali") || n.contains("kgsl")) dirs.add(it.path + "/")
            }
        } catch (_: Exception) {
        }
        for (d in dirs) {
            val c = readLong(d + "cur_freq") ?: continue
            if (c > 0L) return if (c > 10_000_000L) c / 1_000_000.0 else c / 1000.0
        }
        return -1.0
    }

    fun brightPct(ctx: Context): Int = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100 / 255
    } catch (e: Exception) {
        50
    }

    fun setBright(ctx: Context, pct: Int): Boolean {
        if (!Settings.System.canWrite(ctx)) return false
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (pct * 255 / 100).coerceIn(1, 255))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun autoLight(ctx: Context): Boolean = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE) == 1
    } catch (e: Exception) {
        false
    }

    fun setAutoLight(ctx: Context, on: Boolean): Boolean {
        if (!Settings.System.canWrite(ctx)) return false
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, if (on) 1 else 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun rotateOn(ctx: Context): Boolean = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION) == 1
    } catch (e: Exception) {
        false
    }

    fun setRotate(ctx: Context, on: Boolean): Boolean {
        if (!Settings.System.canWrite(ctx)) return false
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun volPct(ctx: Context): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (mx <= 0) 0 else am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx
    }

    fun setVol(ctx: Context, pct: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (mx * pct / 100).coerceIn(0, mx), 0)
    }

    /** Cooling: tutup app background + turunkan kecerahan (kalau izin ada). Tidak mendinginkan hardware. */
    fun cooling(ctx: Context, on: Boolean): JSONObject {
        val p = Games.prefs(ctx)
        val o = JSONObject()
        val t0 = Booster.batteryTempC(ctx)
        if (on) {
            val n = Booster.boost(ctx, emptySet())
            var dimmed = false
            if (Settings.System.canWrite(ctx) && !p.getBoolean("cool_on", false)) {
                try {
                    val cr = ctx.contentResolver
                    val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
                    val md = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                    p.edit().putInt("cool_b", cur).putInt("cool_m", md).apply()
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, if (cur < 110) cur else 110)
                    dimmed = true
                } catch (e: Exception) {
                }
            }
            p.edit().putBoolean("cool_on", true).putFloat("cool_t", t0 ?: -1f).apply()
            o.put("closed", n).put("dimmed", dimmed)
        } else {
            if (p.contains("cool_b") && Settings.System.canWrite(ctx)) {
                try {
                    val cr = ctx.contentResolver
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, p.getInt("cool_b", 128))
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, p.getInt("cool_m", 0))
                } catch (e: Exception) {
                }
            }
            p.edit().remove("cool_b").remove("cool_m").putBoolean("cool_on", false).apply()
        }
        return o.put("on", on)
    }

    fun realSize(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    fun a11yEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("RbAccessibilityService")
    }

    fun storageGb(): Pair<Double, Double> {
        return try {
            val st = android.os.StatFs(Environment.getDataDirectory().path)
            val free = st.availableBytes / 1073741824.0
            val total = st.totalBytes / 1073741824.0
            Pair(free, total)
        } catch (e: Exception) {
            Pair(-1.0, -1.0)
        }
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun savePng(ctx: Context, bmp: Bitmap): Boolean {
        return try {
            val name = "RBOOST_" + stamp() + ".png"
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RBoost")
                val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (u == null) {
                    false
                } else {
                    ctx.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    true
                }
            } else {
                val d = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                File(d, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun videoName(): String = "RBOOST_" + stamp() + ".mp4"
}
